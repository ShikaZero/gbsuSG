package com.kata.gbsuftblai

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GbsuFtbLaiApplicationTests {

    @Test
    fun contextLoads() {

    }

}
